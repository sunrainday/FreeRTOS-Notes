# FreeRTOS 学习笔记

这是一个基于 Markdown 格式的 FreeRTOS 学习笔记项目，适合用 VS Code 和 Git 管理。
